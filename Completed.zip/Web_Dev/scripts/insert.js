function insert(e) {
  const task = {
    id: Math.floor(Math.random() * 100000),
    name: e.target[0].value,
    desc: e.target[1].value,
  };
  if (task.name == "" || task.desc == "") {
    return null;
  }
  const tasks = JSON.parse(localStorage.getItem("tasks") || "[]");
  tasks.push(task);
  localStorage.setItem("tasks", JSON.stringify(tasks));
}
