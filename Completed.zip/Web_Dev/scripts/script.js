let currentTask = null;
function onLoad() {
  const container = document.getElementById("tasks");
  let tasks = JSON.parse(localStorage.getItem("tasks") || "[]");
  tasks = tasks.reverse();
  const mappedTasks = tasks.map((task, index) => {
    return `<div class="task">
                <img name=${task.id} src="/assets/edit.svg" alt="Edit Icon" onclick="openEdit(this)"/>
                <h1>${task.name}</h1>
                <p>${task.desc}</p>
                <button name=${task.id} onclick="deleteTask(this)">Done</button>
            </div>`;
  });
  container.innerHTML = mappedTasks.join(" ");
}

function deleteTask(task) {
  const tasks = JSON.parse(localStorage.getItem("tasks") || "[]");
  const newTasks = tasks.filter(function filtering(taskT) {
    return taskT.id != task.name;
  });
  localStorage.setItem("tasks", JSON.stringify(newTasks));
  onLoad();
}

function openEdit(task) {
  currentTask = task.name;
  const form = document.getElementById("Form");
  form.classList.toggle("formbg");
  form.classList.toggle("hidden");
}

function closeEdit() {
  const form = document.getElementById("Form");
  form.classList.toggle("formbg");
  form.classList.toggle("hidden");
}

function editTask(e) {
  e.preventDefault();
  let task = {};
  if (e.target[0].value != null && e.target[0].value != "") {
    task = { ...task, name: e.target[0].value };
  }
  if (e.target[1].value != null && e.target[1].value != "") {
    task = { ...task, desc: e.target[1].value };
  }
  let tasks = JSON.parse(localStorage.getItem("tasks") || "[]");
  let editedTask = tasks.filter(function filtering(taskT) {
    return taskT.id == currentTask;
  })[0];
  tasks = tasks.filter(function filtering(taskT) {
    return taskT.id != currentTask;
  });
  editedTask = { ...editedTask, ...task };
  tasks = [...tasks, editedTask];
  e.target[0].value = "";
  e.target[1].value = "";
  closeEdit();
  localStorage.setItem("tasks", JSON.stringify(tasks));
  onLoad();
}

function clearTasks() {
  localStorage.setItem("tasks", []);
  onLoad();
}

onLoad();
